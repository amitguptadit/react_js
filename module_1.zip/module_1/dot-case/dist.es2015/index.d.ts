import { Options } from "no-case";
export { Options };
export declare function dotCase(input: string, options?: Options): string;
