'use strict';

module.exports = require('./lib/detect-port');
